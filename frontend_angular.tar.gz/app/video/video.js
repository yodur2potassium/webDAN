"use strict";
var Video = (function () {
    function Video() {
    }
    return Video;
}());
exports.Video = Video;
//# sourceMappingURL=video.js.map