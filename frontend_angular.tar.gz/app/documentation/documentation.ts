export class Documentation{
  id: number;
  source: string;
  lang: string;
}
