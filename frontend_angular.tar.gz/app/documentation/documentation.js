"use strict";
var Documentation = (function () {
    function Documentation() {
    }
    return Documentation;
}());
exports.Documentation = Documentation;
//# sourceMappingURL=documentation.js.map