"use strict";
var Article = (function () {
    function Article() {
    }
    return Article;
}());
exports.Article = Article;
//# sourceMappingURL=article.js.map