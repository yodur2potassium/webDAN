import { Component } from "@angular/core";

@Component ({
  selector: 'my-form',
  templateUrl: 'app/form/form.html',
  styles: [`
      form {
        padding: 15px;
      }
    `]
})

export class FormComponent {

}
