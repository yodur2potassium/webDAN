"use strict";
var Image = (function () {
    function Image() {
    }
    return Image;
}());
exports.Image = Image;
//# sourceMappingURL=image.js.map